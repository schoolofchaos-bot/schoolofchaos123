import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

interface EventCardProps {
  id: string;
  title: string;
  shortDescription: string;
  thumbnailUrl: string;
}

export default function EventCard({ id, title, shortDescription, thumbnailUrl }: EventCardProps) {
  return (
    <Card className="overflow-hidden hover-elevate transition-transform duration-200 hover:scale-105" data-testid={`card-event-${id}`}>
      <div className="aspect-[16/9] overflow-hidden">
        <img
          src={thumbnailUrl}
          alt={title}
          className="w-full h-full object-cover"
          data-testid={`img-event-thumbnail-${id}`}
        />
      </div>
      <CardContent className="p-4 md:p-6">
        <h3 className="font-display font-bold text-xl md:text-2xl mb-2 line-clamp-2" data-testid={`text-event-title-${id}`}>
          {title}
        </h3>
        <p className="text-sm md:text-base text-muted-foreground line-clamp-3" data-testid={`text-event-description-${id}`}>
          {shortDescription}
        </p>
      </CardContent>
      <CardFooter className="p-4 md:p-6 pt-0">
        <Link href={`/events/${id}`}>
          <Button className="w-full gap-2" data-testid={`button-read-more-${id}`}>
            Read More
            <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
