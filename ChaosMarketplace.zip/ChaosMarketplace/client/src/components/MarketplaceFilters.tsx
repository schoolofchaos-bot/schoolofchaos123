import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface MarketplaceFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  itemType: string;
  onItemTypeChange: (value: string) => void;
  minLevel: string;
  onMinLevelChange: (value: string) => void;
  maxLevel: string;
  onMaxLevelChange: (value: string) => void;
}

export default function MarketplaceFilters({
  searchQuery,
  onSearchChange,
  itemType,
  onItemTypeChange,
  minLevel,
  onMinLevelChange,
  maxLevel,
  onMaxLevelChange,
}: MarketplaceFiltersProps) {
  return (
    <div className="bg-card p-4 md:p-6 rounded-lg border border-card-border space-y-4">
      <h3 className="font-display font-bold text-lg md:text-xl mb-4">Search & Filter</h3>
      
      {/* Search */}
      <div className="space-y-2">
        <Label htmlFor="search">Search by Name</Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            id="search"
            type="search"
            placeholder="Search items..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 h-12"
            data-testid="input-search"
          />
        </div>
      </div>

      {/* Item Type */}
      <div className="space-y-2">
        <Label htmlFor="itemType">Item Type</Label>
        <Select value={itemType} onValueChange={onItemTypeChange}>
          <SelectTrigger className="h-12" data-testid="select-item-type">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="Weapon">Weapon</SelectItem>
            <SelectItem value="Armor">Armor</SelectItem>
            <SelectItem value="Consumable">Consumable</SelectItem>
            <SelectItem value="Bags">Bags</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Level Range */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="minLevel">Min Level</Label>
          <Input
            id="minLevel"
            type="number"
            placeholder="0"
            value={minLevel}
            onChange={(e) => onMinLevelChange(e.target.value)}
            className="h-12"
            data-testid="input-min-level"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="maxLevel">Max Level</Label>
          <Input
            id="maxLevel"
            type="number"
            placeholder="999"
            value={maxLevel}
            onChange={(e) => onMaxLevelChange(e.target.value)}
            className="h-12"
            data-testid="input-max-level"
          />
        </div>
      </div>
    </div>
  );
}
