import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface MarketplaceItemCardProps {
  id: string;
  itemName: string;
  itemType: string;
  level: number;
  price: number;
  currency: string;
  damage?: number;
  imageUrl: string;
  expiresAt: Date;
}

export default function MarketplaceItemCard({
  id,
  itemName,
  itemType,
  level,
  price,
  currency,
  damage,
  imageUrl,
  expiresAt,
}: MarketplaceItemCardProps) {
  const timeRemaining = formatDistanceToNow(expiresAt, { addSuffix: true });
  const hoursRemaining = (expiresAt.getTime() - Date.now()) / (1000 * 60 * 60);
  const isExpiringSoon = hoursRemaining < 6;

  return (
    <Card className="overflow-hidden hover-elevate transition-transform duration-200 hover:scale-105 relative" data-testid={`card-item-${id}`}>
      {/* Expiration Badge */}
      <Badge
        variant={isExpiringSoon ? "destructive" : "secondary"}
        className={`absolute top-2 right-2 z-10 gap-1 ${isExpiringSoon ? "animate-pulse" : ""}`}
        data-testid={`badge-expiry-${id}`}
      >
        <Clock className="w-3 h-3" />
        {timeRemaining}
      </Badge>

      {/* Item Image */}
      <div className="aspect-square bg-muted p-4">
        <img
          src={imageUrl}
          alt={itemName}
          className="w-full h-full object-contain"
          data-testid={`img-item-${id}`}
        />
      </div>

      <CardContent className="p-4">
        {/* Item Name */}
        <h3 className="font-semibold text-base line-clamp-1 mb-2" data-testid={`text-item-name-${id}`}>
          {itemName}
        </h3>

        {/* Metadata Grid */}
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-muted-foreground">Type:</span>
            <Badge variant="outline" className="ml-1" data-testid={`badge-type-${id}`}>
              {itemType}
            </Badge>
          </div>
          <div>
            <span className="text-muted-foreground">Level:</span>
            <span className="ml-1 font-medium" data-testid={`text-level-${id}`}>{level}</span>
          </div>
          {damage !== undefined && (
            <div className="col-span-2">
              <span className="text-muted-foreground">Damage:</span>
              <span className="ml-1 font-medium text-destructive" data-testid={`text-damage-${id}`}>{damage}</span>
            </div>
          )}
          <div className="col-span-2">
            <span className="text-muted-foreground">Price:</span>
            <span className="ml-1 font-bold text-primary" data-testid={`text-price-${id}`}>
              {price} {currency}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
