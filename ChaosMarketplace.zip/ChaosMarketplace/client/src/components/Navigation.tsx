import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Home, Newspaper, ShoppingCart, LogIn, LogOut, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import AuthDialog from "./AuthDialog";
import ThemeToggle from "./ThemeToggle";
import logoUrl from "@assets/schoolofchaoslogo_1761394366390.png";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [location] = useLocation();
  const { isAuthenticated, username, logout } = useAuth();

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/events", label: "Events & News", icon: Newspaper },
    { path: "/marketplace", label: "Marketplace", icon: ShoppingCart },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-card-border">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 hover-elevate active-elevate-2 rounded-lg p-2 -ml-2">
            <img src={logoUrl} alt="School of Chaos" className="h-10 md:h-12 w-10 md:w-12 rounded-lg" data-testid="img-logo" />
            <span className="font-display font-bold text-lg md:text-xl text-foreground hidden sm:block">
              School of Chaos
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={isActive(item.path) ? "default" : "ghost"}
                  className="gap-2"
                  data-testid={`link-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </Button>
              </Link>
            ))}
            
            {/* Theme Toggle */}
            <ThemeToggle />
            
            {/* Auth Button */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <Button variant="ghost" className="gap-2" data-testid="button-user-profile">
                  <User className="w-5 h-5" />
                  {username}
                </Button>
                <Button variant="ghost" size="icon" onClick={logout} data-testid="button-logout">
                  <LogOut className="w-5 h-5" />
                </Button>
              </div>
            ) : (
              <Button variant="default" className="gap-2" onClick={() => setAuthDialogOpen(true)} data-testid="button-auth">
                <LogIn className="w-5 h-5" />
                Login
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
            data-testid="button-menu-toggle"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-card border-t border-card-border">
          <div className="px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path} onClick={() => setIsOpen(false)}>
                <Button
                  variant={isActive(item.path) ? "default" : "ghost"}
                  className="w-full justify-start gap-2"
                  data-testid={`link-nav-mobile-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </Button>
              </Link>
            ))}
            
            {/* Mobile Theme Toggle */}
            <div className="border-t border-card-border pt-2 mt-2">
              <div className="flex items-center justify-between px-3 py-2">
                <span className="text-sm font-medium">Theme</span>
                <ThemeToggle />
              </div>
            </div>
            
            {/* Mobile Auth */}
            <div className="border-t border-card-border pt-2">
              {isAuthenticated ? (
                <>
                  <Button variant="ghost" className="w-full justify-start gap-2" data-testid="button-mobile-profile">
                    <User className="w-5 h-5" />
                    {username}
                  </Button>
                  <Button variant="ghost" className="w-full justify-start gap-2" onClick={() => { logout(); setIsOpen(false); }} data-testid="button-mobile-logout">
                    <LogOut className="w-5 h-5" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button variant="default" className="w-full justify-start gap-2" onClick={() => { setAuthDialogOpen(true); setIsOpen(false); }} data-testid="button-mobile-auth">
                  <LogIn className="w-5 h-5" />
                  Login
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
      
      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />
    </nav>
  );
}
