import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, LogIn } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth-context";
import { useMarketplace } from "@/lib/marketplace-context";
import AuthDialog from "./AuthDialog";

const itemSchema = z.object({
  itemType: z.string().min(1, "Item type is required"),
  itemName: z.string().min(1, "Item name is required"),
  level: z.string().min(1, "Level is required"),
  price: z.string().min(1, "Price is required"),
  currency: z.string().min(1, "Currency is required"),
  damage: z.string().optional(),
  description: z.string().optional(),
});

const requestSchema = z.object({
  itemName: z.string().min(1, "Item name is required"),
  minLevel: z.string().min(1, "Min level is required"),
  maxLevel: z.string().min(1, "Max level is required"),
  description: z.string().optional(),
});

export default function PostItemForm() {
  const [activeTab, setActiveTab] = useState("sell");
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, username } = useAuth();
  const { addItem, addRequest } = useMarketplace();

  const itemForm = useForm({
    resolver: zodResolver(itemSchema),
    defaultValues: {
      itemType: "",
      itemName: "",
      level: "",
      price: "",
      currency: "VIPs",
      damage: "",
      description: "",
    },
  });

  const requestForm = useForm({
    resolver: zodResolver(requestSchema),
    defaultValues: {
      itemName: "",
      minLevel: "",
      maxLevel: "",
      description: "",
    },
  });

  const itemType = itemForm.watch("itemType");

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmitItem = (data: z.infer<typeof itemSchema>) => {
    if (!isAuthenticated || !username) {
      setAuthDialogOpen(true);
      return;
    }

    addItem(
      {
        itemName: data.itemName,
        itemType: data.itemType,
        level: parseInt(data.level),
        price: parseInt(data.price),
        currency: data.currency,
        damage: data.damage ? parseInt(data.damage) : undefined,
        imageUrl: selectedImage || "https://via.placeholder.com/200",
        description: data.description,
      },
      username
    );

    toast({
      title: "Item Posted!",
      description: `${data.itemName} has been listed in the marketplace for 48 hours.`,
    });
    itemForm.reset();
    setSelectedImage("");
  };

  const onSubmitRequest = (data: z.infer<typeof requestSchema>) => {
    if (!isAuthenticated || !username) {
      setAuthDialogOpen(true);
      return;
    }

    addRequest(
      {
        itemName: data.itemName,
        minLevel: parseInt(data.minLevel),
        maxLevel: parseInt(data.maxLevel),
        description: data.description,
      },
      username
    );

    toast({
      title: "Request Posted!",
      description: `Looking for ${data.itemName} (Level ${data.minLevel}-${data.maxLevel})`,
    });
    requestForm.reset();
  };

  return (
    <>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="font-display text-2xl md:text-3xl">Post Item or Request</CardTitle>
          {!isAuthenticated && (
            <p className="text-muted-foreground text-sm mt-2">
              Please login to post items or requests
            </p>
          )}
        </CardHeader>
        <CardContent>
          {!isAuthenticated ? (
            <div className="py-12 text-center space-y-4">
              <p className="text-muted-foreground">You need to be logged in to post items or requests.</p>
              <Button onClick={() => setAuthDialogOpen(true)} className="gap-2" data-testid="button-login-to-post">
                <LogIn className="w-5 h-5" />
                Login to Continue
              </Button>
            </div>
          ) : (
            <div>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="sell" data-testid="tab-sell-item">Sell Item</TabsTrigger>
            <TabsTrigger value="request" data-testid="tab-purchase-request">Purchase Request</TabsTrigger>
          </TabsList>

          {/* Sell Item Tab */}
          <TabsContent value="sell">
            <form onSubmit={itemForm.handleSubmit(onSubmitItem)} className="space-y-6">
              {/* Item Type */}
              <div className="space-y-2">
                <Label htmlFor="itemType">Item Type *</Label>
                <Select
                  value={itemForm.watch("itemType")}
                  onValueChange={(value) => itemForm.setValue("itemType", value)}
                >
                  <SelectTrigger className="h-12" data-testid="select-post-item-type">
                    <SelectValue placeholder="Select item type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Weapon">Weapon</SelectItem>
                    <SelectItem value="Armor">Armor</SelectItem>
                    <SelectItem value="Consumable">Consumable</SelectItem>
                    <SelectItem value="Bags">Bags</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Item Name */}
              <div className="space-y-2">
                <Label htmlFor="itemName">Item Name *</Label>
                <Input
                  id="itemName"
                  {...itemForm.register("itemName")}
                  placeholder="Enter item name"
                  className="h-12"
                  data-testid="input-item-name"
                />
              </div>

              {/* Level */}
              <div className="space-y-2">
                <Label htmlFor="level">Level *</Label>
                <Input
                  id="level"
                  type="number"
                  {...itemForm.register("level")}
                  placeholder="Enter level"
                  className="h-12"
                  data-testid="input-item-level"
                />
              </div>

              {/* Damage (only for weapons) */}
              {itemType === "Weapon" && (
                <div className="space-y-2">
                  <Label htmlFor="damage">Damage</Label>
                  <Input
                    id="damage"
                    type="number"
                    {...itemForm.register("damage")}
                    placeholder="Enter damage value"
                    className="h-12"
                    data-testid="input-item-damage"
                  />
                </div>
              )}

              {/* Price and Currency */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Price *</Label>
                  <Input
                    id="price"
                    type="number"
                    {...itemForm.register("price")}
                    placeholder="Enter price"
                    className="h-12"
                    data-testid="input-item-price"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency *</Label>
                  <Select
                    value={itemForm.watch("currency")}
                    onValueChange={(value) => itemForm.setValue("currency", value)}
                  >
                    <SelectTrigger className="h-12" data-testid="select-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="VIPs">VIPs</SelectItem>
                      <SelectItem value="Nametags">Nametags</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="itemDescription">Description (Optional)</Label>
                <Textarea
                  id="itemDescription"
                  {...itemForm.register("description")}
                  placeholder="Add a short description..."
                  className="min-h-24 resize-y"
                  data-testid="textarea-item-description"
                />
              </div>

              {/* Image Upload */}
              <div className="space-y-2">
                <Label htmlFor="image">Item Image *</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover-elevate cursor-pointer min-h-40 flex flex-col items-center justify-center">
                  <input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    data-testid="input-image-upload"
                  />
                  <label htmlFor="image" className="cursor-pointer w-full">
                    {selectedImage ? (
                      <img src={selectedImage} alt="Preview" className="max-h-32 mx-auto" />
                    ) : (
                      <>
                        <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                        <p className="text-muted-foreground">Click to upload item image</p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              {/* Submit Button */}
              <Button type="submit" className="w-full h-12" data-testid="button-submit-item">
                Post Item (Expires in 48h)
              </Button>
            </form>
          </TabsContent>

          {/* Purchase Request Tab */}
          <TabsContent value="request">
            <form onSubmit={requestForm.handleSubmit(onSubmitRequest)} className="space-y-6">
              {/* Item Name */}
              <div className="space-y-2">
                <Label htmlFor="requestItemName">Item Name *</Label>
                <Input
                  id="requestItemName"
                  {...requestForm.register("itemName")}
                  placeholder="What are you looking for?"
                  className="h-12"
                  data-testid="input-request-item-name"
                />
              </div>

              {/* Level Range */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="requestMinLevel">Min Level *</Label>
                  <Input
                    id="requestMinLevel"
                    type="number"
                    {...requestForm.register("minLevel")}
                    placeholder="Min level"
                    className="h-12"
                    data-testid="input-request-min-level"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="requestMaxLevel">Max Level *</Label>
                  <Input
                    id="requestMaxLevel"
                    type="number"
                    {...requestForm.register("maxLevel")}
                    placeholder="Max level"
                    className="h-12"
                    data-testid="input-request-max-level"
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label htmlFor="requestDescription">Description (Optional)</Label>
                <Textarea
                  id="requestDescription"
                  {...requestForm.register("description")}
                  placeholder="Add any specific requirements or notes..."
                  className="min-h-24 resize-y"
                  data-testid="textarea-request-description"
                />
              </div>

              {/* Submit Button */}
              <Button type="submit" variant="secondary" className="w-full h-12" data-testid="button-submit-request">
                Post Purchase Request (Expires in 48h)
              </Button>
            </form>
          </TabsContent>
        </Tabs>
          </div>
          )}
        </CardContent>
      </Card>
      <AuthDialog open={authDialogOpen} onOpenChange={setAuthDialogOpen} />
    </>
  );
}
