import EventCard from "../EventCard";
import event1 from "@assets/event1_1761394300863.jpg";

export default function EventCardExample() {
  return (
    <div className="max-w-sm">
      <EventCard
        id="1"
        title="Spooky Season Event"
        shortDescription="Join us for the spookiest event of the year! Show off your Halloween costumes and win amazing prizes."
        thumbnailUrl={event1}
      />
    </div>
  );
}
