import { useState } from "react";
import MarketplaceFilters from "../MarketplaceFilters";

export default function MarketplaceFiltersExample() {
  const [searchQuery, setSearchQuery] = useState("");
  const [itemType, setItemType] = useState("all");
  const [minLevel, setMinLevel] = useState("");
  const [maxLevel, setMaxLevel] = useState("");

  return (
    <div className="max-w-md">
      <MarketplaceFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        itemType={itemType}
        onItemTypeChange={setItemType}
        minLevel={minLevel}
        onMinLevelChange={setMinLevel}
        maxLevel={maxLevel}
        onMaxLevelChange={setMaxLevel}
      />
    </div>
  );
}
