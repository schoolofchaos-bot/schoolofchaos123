import MarketplaceItemCard from "../MarketplaceItemCard";
import item1 from "@assets/item1 weapon_1761394951280.jpg";

export default function MarketplaceItemCardExample() {
  return (
    <div className="max-w-xs">
      <MarketplaceItemCard
        id="1"
        itemName="Giant Plastic Sword"
        itemType="Weapon"
        level={230}
        price={5000}
        currency="VIPs"
        damage={113}
        imageUrl={item1}
        expiresAt={new Date(Date.now() + 24 * 60 * 60 * 1000)}
      />
    </div>
  );
}
