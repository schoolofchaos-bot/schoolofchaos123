import { createContext, useContext, useState, ReactNode } from "react";

export interface MarketplaceItem {
  id: string;
  itemName: string;
  itemType: string;
  level: number;
  price: number;
  currency: string;
  damage?: number;
  imageUrl: string;
  description?: string;
  expiresAt: Date;
  postedBy: string;
}

export interface PurchaseRequest {
  id: string;
  itemName: string;
  minLevel: number;
  maxLevel: number;
  description?: string;
  expiresAt: Date;
  postedBy: string;
}

interface MarketplaceContextType {
  items: MarketplaceItem[];
  requests: PurchaseRequest[];
  addItem: (item: Omit<MarketplaceItem, "id" | "expiresAt" | "postedBy">, postedBy: string) => void;
  addRequest: (request: Omit<PurchaseRequest, "id" | "expiresAt" | "postedBy">, postedBy: string) => void;
}

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export function MarketplaceProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [requests, setRequests] = useState<PurchaseRequest[]>([]);

  const addItem = (item: Omit<MarketplaceItem, "id" | "expiresAt" | "postedBy">, postedBy: string) => {
    const newItem: MarketplaceItem = {
      ...item,
      id: `user-${Date.now()}-${Math.random()}`,
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
      postedBy,
    };
    setItems((prev) => [newItem, ...prev]);
  };

  const addRequest = (request: Omit<PurchaseRequest, "id" | "expiresAt" | "postedBy">, postedBy: string) => {
    const newRequest: PurchaseRequest = {
      ...request,
      id: `req-${Date.now()}-${Math.random()}`,
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
      postedBy,
    };
    setRequests((prev) => [newRequest, ...prev]);
  };

  return (
    <MarketplaceContext.Provider value={{ items, requests, addItem, addRequest }}>
      {children}
    </MarketplaceContext.Provider>
  );
}

export function useMarketplace() {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error("useMarketplace must be used within MarketplaceProvider");
  }
  return context;
}
