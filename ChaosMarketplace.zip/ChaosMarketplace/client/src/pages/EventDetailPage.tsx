import { useRoute, Link } from "wouter";
import Navigation from "@/components/Navigation";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import news1 from "@assets/news1_1761394300862.jpg";
import event1 from "@assets/event1_1761394300863.jpg";
import event2 from "@assets/event2_1761394300863.jpg";

export default function EventDetailPage() {
  const [, params] = useRoute("/events/:id");
  const eventId = params?.id || "1";

  //todo: remove mock functionality - replace with real data from API
  const eventsData: Record<string, any> = {
    "1": {
      title: "Cross-Trading Ban Announcement",
      imageUrl: news1,
      fullDescription: `Important Update - October 1st, 2025

Starting today, cross-trading using VIP and Nametags is now officially banned in School of Chaos. This decision has been made to maintain game balance and ensure fair play for all players.

What does this mean?
• Trading VIP status or Nametags for in-game items is prohibited
• Violators will face account suspension
• All trades should be conducted using in-game currency only

This change is essential to protect the integrity of our marketplace and ensure everyone has a fair chance to succeed.

Thank you for your understanding and continued support!`,
    },
    "2": {
      title: "Spooky Season 2025",
      imageUrl: event1,
      fullDescription: `Halloween Week 2025 - The Spookiest Season Yet!

Get ready for the most terrifying and exciting Halloween celebration in School of Chaos history!

Event Details:
• Special Halloween-themed locations and missions
• Exclusive spooky costumes and items
• Limited-time Halloween weapons and armor
• Trick-or-treat style rewards system
• Haunted school zones with special boss fights

Don't miss out on this limited-time event. Join the chaos and collect exclusive Halloween rewards!

Event runs throughout October 2025.`,
    },
    "3": {
      title: "Halloween Outfit Contest",
      imageUrl: event2,
      fullDescription: `Halloween Outfit Contest 2025

Show off your creativity and win amazing prizes!

How to Join:
1. Create a Halloween-themed outfit in School of Chaos
2. Take a creative screenshot in any location (editing allowed)
3. Post your entry with the hashtag #SoCHalloween2025 + your in-game name

Deadline: October 27, 2025 (UTC)

Prizes:
• 1st Place: Exclusive Halloween Legendary Item Set
• 2nd Place: 10,000 VIPs + Rare Halloween Costume
• 3rd Place: 5,000 VIPs + Special Halloween Mask
• Participation Rewards: All valid entries receive special badges

Winners will be announced on October 31st. Good luck and get creative!`,
    },
  };

  const event = eventsData[eventId] || eventsData["1"];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Back Button */}
        <Link href="/events">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
            Back to Events
          </Button>
        </Link>

        {/* Event Image */}
        <div className="mb-8 rounded-lg overflow-hidden">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full max-h-[50vh] object-cover"
            data-testid="img-event-detail"
          />
        </div>

        {/* Event Content */}
        <div className="space-y-6">
          <h1 className="font-display font-bold text-3xl md:text-5xl" data-testid="text-event-title">
            {event.title}
          </h1>
          <div className="prose prose-lg max-w-none">
            <p className="text-lg md:text-xl whitespace-pre-line text-foreground" data-testid="text-event-content">
              {event.fullDescription}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
