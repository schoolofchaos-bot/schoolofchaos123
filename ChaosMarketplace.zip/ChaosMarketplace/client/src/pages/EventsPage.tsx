import Navigation from "@/components/Navigation";
import EventCard from "@/components/EventCard";
import news1 from "@assets/news1_1761394300862.jpg";
import event1 from "@assets/event1_1761394300863.jpg";
import event2 from "@assets/event2_1761394300863.jpg";

export default function EventsPage() {
  //todo: remove mock functionality - replace with real data from API
  const events = [
    {
      id: "1",
      title: "Cross-Trading Ban Announcement",
      shortDescription: "Important update: Cross-trading using VIP and Nametags is now banned. This change takes effect October 1st to maintain game balance and fair play.",
      thumbnailUrl: news1,
    },
    {
      id: "2",
      title: "Spooky Season 2025",
      shortDescription: "Get ready for the spookiest season yet! Halloween costumes, special events, and exclusive rewards await. Join the chaos!",
      thumbnailUrl: event1,
    },
    {
      id: "3",
      title: "Halloween Outfit Contest",
      shortDescription: "Create your best Halloween-themed outfit and win amazing prizes! Deadline: October 27, 2025. Post your entry with #SoCHalloween2025 + your in-game name.",
      thumbnailUrl: event2,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Page Header */}
        <div className="mb-8 md:mb-12">
          <h1 className="font-display font-bold text-4xl md:text-5xl mb-4">Events & News</h1>
          <p className="text-lg text-muted-foreground">
            Stay updated with the latest events, announcements, and contests in School of Chaos!
          </p>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {events.map((event) => (
            <EventCard key={event.id} {...event} />
          ))}
        </div>
      </div>
    </div>
  );
}
