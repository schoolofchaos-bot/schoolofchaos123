import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Apple, PlayCircle } from "lucide-react";
import Navigation from "@/components/Navigation";
import logoUrl from "@assets/schoolofchaoslogo_1761394366390.png";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative bg-gradient-to-b from-primary/20 to-background">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-24">
          <div className="text-center space-y-8">
            {/* Logo */}
            <div className="flex justify-center">
              <img 
                src={logoUrl} 
                alt="School of Chaos" 
                className="w-32 h-32 md:w-48 md:h-48 rounded-2xl shadow-xl"
                data-testid="img-hero-logo"
              />
            </div>

            {/* Title */}
            <div className="space-y-4">
              <h1 className="font-display font-bold text-4xl md:text-7xl text-foreground tracking-tight">
                School of Chaos
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
                Survive the ultimate MMORPG experience. Battle, trade, and rise through the chaos!
              </p>
            </div>

            {/* Download Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Button 
                size="lg" 
                className="gap-2 h-14 px-8 w-full sm:w-auto"
                data-testid="button-app-store"
              >
                <Apple className="w-6 h-6" />
                Download on App Store
              </Button>
              <Button 
                size="lg" 
                variant="secondary"
                className="gap-2 h-14 px-8 w-full sm:w-auto"
                data-testid="button-google-play"
              >
                <PlayCircle className="w-6 h-6" />
                Get it on Google Play
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center space-y-4 p-6">
            <div className="text-5xl">⚔️</div>
            <h3 className="font-display font-bold text-xl md:text-2xl">Epic Battles</h3>
            <p className="text-muted-foreground">
              Engage in intense PvP combat and conquer your rivals in the ultimate survival game.
            </p>
          </div>
          <div className="text-center space-y-4 p-6">
            <div className="text-5xl">🛒</div>
            <h3 className="font-display font-bold text-xl md:text-2xl">Trade & Sell</h3>
            <p className="text-muted-foreground">
              Buy and sell items in the marketplace. Build your fortune and upgrade your gear.
            </p>
          </div>
          <div className="text-center space-y-4 p-6">
            <div className="text-5xl">🎉</div>
            <h3 className="font-display font-bold text-xl md:text-2xl">Events & Contests</h3>
            <p className="text-muted-foreground">
              Join seasonal events, participate in contests, and win exclusive rewards.
            </p>
          </div>
        </div>

        {/* CTA to Events */}
        <div className="text-center mt-12">
          <Link href="/events">
            <Button size="lg" className="gap-2 h-12" data-testid="button-view-events">
              View Latest Events & News
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
