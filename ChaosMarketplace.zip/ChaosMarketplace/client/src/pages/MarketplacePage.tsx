import { useState, useMemo } from "react";
import Navigation from "@/components/Navigation";
import MarketplaceItemCard from "@/components/MarketplaceItemCard";
import MarketplaceFilters from "@/components/MarketplaceFilters";
import PostItemForm from "@/components/PostItemForm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMarketplace } from "@/lib/marketplace-context";
import item1 from "@assets/item1 weapon_1761394951280.jpg";
import item2 from "@assets/item2weapon_1761394976679.jpg";
import item3 from "@assets/item3armor_1761394944948.jpg";
import item4 from "@assets/item4armor_1761394939558.jpg";
import item5 from "@assets/item5weapon_1761394939559.jpg";
import item6 from "@assets/item4bag_1761394951279.jpg";

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [itemType, setItemType] = useState("all");
  const [minLevel, setMinLevel] = useState("");
  const [maxLevel, setMaxLevel] = useState("");
  const { items: userItems, requests } = useMarketplace();

  //todo: remove mock functionality - replace with real data from API
  const mockItems = [
    {
      id: "1",
      itemName: "Giant Plastic Sword",
      itemType: "Weapon",
      level: 230,
      price: 5000,
      currency: "VIPs",
      damage: 113,
      imageUrl: item1,
      expiresAt: new Date(Date.now() + 36 * 60 * 60 * 1000), // 36 hours
    },
    {
      id: "2",
      itemName: "BBQ Bonger",
      itemType: "Weapon",
      level: 190,
      price: 8000,
      currency: "VIPs",
      damage: 293,
      imageUrl: item2,
      expiresAt: new Date(Date.now() + 12 * 60 * 60 * 1000), // 12 hours
    },
    {
      id: "3",
      itemName: "Cyber Head Mask",
      itemType: "Armor",
      level: 170,
      price: 3500,
      currency: "Nametags",
      imageUrl: item3,
      expiresAt: new Date(Date.now() + 28 * 60 * 60 * 1000), // 28 hours
    },
    {
      id: "4",
      itemName: "CNY2025 Lunar Armor Set",
      itemType: "Armor",
      level: 200,
      price: 12000,
      currency: "VIPs",
      imageUrl: item4,
      expiresAt: new Date(Date.now() + 42 * 60 * 60 * 1000), // 42 hours
    },
    {
      id: "5",
      itemName: "Grim Reaper Scythe",
      itemType: "Weapon",
      level: 165,
      price: 6500,
      currency: "VIPs",
      damage: 232,
      imageUrl: item5,
      expiresAt: new Date(Date.now() + 5 * 60 * 60 * 1000), // 5 hours (expiring soon)
    },
    {
      id: "6",
      itemName: "Butterfly Wings Bag",
      itemType: "Bags",
      level: 130,
      price: 4000,
      currency: "Nametags",
      imageUrl: item6,
      expiresAt: new Date(Date.now() + 20 * 60 * 60 * 1000), // 20 hours
    },
  ];

  const allItems = useMemo(() => [...userItems, ...mockItems], [userItems]);

  const filteredItems = useMemo(() => {
    return allItems.filter((item) => {
      // Search filter
      if (searchQuery && !item.itemName.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }

      // Type filter
      if (itemType !== "all" && item.itemType !== itemType) {
        return false;
      }

      // Level range filter
      const min = minLevel ? parseInt(minLevel) : 0;
      const max = maxLevel ? parseInt(maxLevel) : 999;
      if (item.level < min || item.level > max) {
        return false;
      }

      return true;
    });
  }, [searchQuery, itemType, minLevel, maxLevel, allItems]);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="font-display font-bold text-4xl md:text-5xl mb-4">Marketplace Station</h1>
          <p className="text-lg text-muted-foreground">
            Browse items, post listings, or create purchase requests. All items expire after 48 hours.
          </p>
        </div>

        <Tabs defaultValue="browse" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="browse" data-testid="tab-browse">Browse Items</TabsTrigger>
            <TabsTrigger value="post" data-testid="tab-post">Post Item/Request</TabsTrigger>
          </TabsList>

          {/* Browse Items Tab */}
          <TabsContent value="browse" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Filters Sidebar */}
              <div className="lg:col-span-1">
                <div className="lg:sticky lg:top-24">
                  <MarketplaceFilters
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                    itemType={itemType}
                    onItemTypeChange={setItemType}
                    minLevel={minLevel}
                    onMinLevelChange={setMinLevel}
                    maxLevel={maxLevel}
                    onMaxLevelChange={setMaxLevel}
                  />
                </div>
              </div>

              {/* Items Grid */}
              <div className="lg:col-span-3 space-y-8">
                {/* Purchase Requests Section */}
                {requests.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-display font-bold text-xl md:text-2xl">Purchase Requests</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {requests.map((request) => (
                        <Card key={request.id} className="hover-elevate" data-testid={`card-request-${request.id}`}>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-semibold text-base" data-testid={`text-request-name-${request.id}`}>
                                {request.itemName}
                              </h4>
                              <Badge variant="secondary">Request</Badge>
                            </div>
                            <div className="space-y-1 text-sm">
                              <p className="text-muted-foreground">
                                Level Range: <span className="font-medium text-foreground">{request.minLevel} - {request.maxLevel}</span>
                              </p>
                              {request.description && (
                                <p className="text-muted-foreground">
                                  Note: <span className="text-foreground">{request.description}</span>
                                </p>
                              )}
                              <p className="text-muted-foreground">
                                Posted by: <span className="font-medium text-foreground">{request.postedBy}</span>
                              </p>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Items Section */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-bold text-xl md:text-2xl">Items for Sale</h3>
                    <p className="text-muted-foreground">
                      {filteredItems.length} item{filteredItems.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                    {filteredItems.map((item) => (
                      <MarketplaceItemCard key={item.id} {...item} />
                    ))}
                  </div>
                  {filteredItems.length === 0 && (
                    <div className="text-center py-12">
                      <p className="text-muted-foreground text-lg">No items match your filters.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Post Item/Request Tab */}
          <TabsContent value="post">
            <div className="max-w-2xl mx-auto">
              <PostItemForm />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
