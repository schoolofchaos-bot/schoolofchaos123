import EventDetailPage from "../EventDetailPage";

export default function EventDetailPageExample() {
  return <EventDetailPage />;
}
