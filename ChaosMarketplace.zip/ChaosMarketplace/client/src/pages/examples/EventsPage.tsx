import EventsPage from "../EventsPage";

export default function EventsPageExample() {
  return <EventsPage />;
}
