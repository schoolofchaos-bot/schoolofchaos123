import MarketplacePage from "../MarketplacePage";

export default function MarketplacePageExample() {
  return <MarketplacePage />;
}
