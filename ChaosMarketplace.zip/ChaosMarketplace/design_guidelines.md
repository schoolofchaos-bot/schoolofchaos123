# School of Chaos - Design Guidelines

## Design Approach
**Reference-Based Gaming Platform Design**
Drawing inspiration from modern gaming marketplaces (Steam, Epic Games Store) and mobile game websites, with emphasis on bold typography, high-contrast layouts, and immersive visual storytelling. The design prioritizes mobile-first interaction patterns while maintaining desktop richness.

## Core Design Principles
1. **Mobile-First Foundation**: All interactions optimized for touch, thumb-friendly button placement, generous tap targets
2. **Gaming Aesthetic**: Bold, energetic design with gritty textures and dramatic visual hierarchy
3. **Content Prominence**: Let game imagery and item cards be heroes - minimal decoration, maximum impact
4. **Instant Clarity**: Users should immediately understand what they're looking at and what actions are available

## Typography System

**Font Families**:
- Primary: Inter or Rubik (bold, modern sans-serif via Google Fonts)
- Accent: Rajdhani or Chakra Petch (gaming-style headers via Google Fonts)

**Hierarchy**:
- H1 (Hero): text-5xl md:text-7xl, font-bold, tracking-tight (Accent font)
- H2 (Section): text-3xl md:text-5xl, font-bold (Accent font)
- H3 (Cards): text-xl md:text-2xl, font-semibold (Primary font)
- Body: text-base md:text-lg, font-normal (Primary font)
- Small/Meta: text-sm, font-medium (Primary font)
- Button Text: text-base md:text-lg, font-semibold, uppercase tracking-wide

## Layout System

**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16, 24 for consistent rhythm (p-4, m-8, gap-6, etc.)

**Container Strategy**:
- Max width: max-w-7xl for main content areas
- Edge padding: px-4 md:px-8 lg:px-12 (mobile-friendly breathing room)
- Section spacing: py-12 md:py-20 lg:py-24

**Grid Systems**:
- Event cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Marketplace items: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 (more density for items)
- Form layouts: Single column on mobile, 2-column on md+ where logical

## Component Library

### Navigation
- Sticky header with School of Chaos logo left-aligned
- Mobile: Hamburger menu (icon from Heroicons) expanding to full-screen overlay
- Desktop: Horizontal menu with hover states
- Height: h-16 md:h-20 with centered content alignment

### Hero Section (Home Page)
- Full-width hero with large School of Chaos logo centered
- Tagline/subtitle underneath logo
- Download buttons stacked vertically on mobile, horizontal on desktop
- Button sizing: Large (h-12 md:h-14), rounded-lg, with store icons (use Heroicons for Apple/Google)
- Background: Use subtle texture or gradient overlay on gaming-themed background image

### Event Cards
- Aspect ratio: aspect-[16/9] for thumbnail images
- Card structure: Image top, content below with p-4 md:p-6
- Title: H3 styling, line-clamp-2 for overflow
- Description: text-sm md:text-base, line-clamp-3
- "Read More" button: Positioned bottom with mt-4
- Hover: Scale transform (scale-105) on desktop, subtle shadow increase
- Border: rounded-lg with overflow-hidden for images

### Event Detail Page
- Hero image: Full width, max-h-[50vh] object-cover
- Content: max-w-4xl mx-auto with generous padding
- Back button: Positioned top-left with arrow icon
- Typography: Larger body text (text-lg md:text-xl) for readability

### Marketplace Items
- Compact card design for higher density
- Image: aspect-square, rounded-lg
- Item name: font-semibold, text-base, line-clamp-1
- Metadata grid: 2-column layout for Level/Type/Price
- Expiration timer: Small badge positioned top-right on card with countdown
- Badge styling: px-2 py-1, rounded-md, text-xs font-medium

### Search & Filter Bar
- Sticky positioned below header on scroll (mobile)
- Search input: Full width on mobile, w-1/2 md:w-1/3 on desktop
- Filter dropdowns: Stack vertically on mobile, horizontal on md+
- Input height: h-12 with rounded-lg borders
- Clear visual separation with backdrop or border

### Post Item/Request Form
- Card-based container: p-6 md:p-8, rounded-lg, shadow-lg
- Input groups: mb-6 spacing between fields
- Label: text-sm font-medium, mb-2
- Input/Select: h-12, rounded-md, full width
- Dynamic fields: Smooth height transition when type changes
- Image upload: Large dropzone area (min-h-40) with dashed border, centered icon and text
- Description textarea: min-h-24, resize-y enabled
- Submit button: w-full on mobile, w-auto px-12 on desktop, positioned right

### Buttons
- Primary: h-12, px-6 md:px-8, rounded-lg, font-semibold, uppercase text-sm
- Secondary: Same sizing, outlined variant
- Icon buttons: w-12 h-12, rounded-full for mobile nav
- Blurred background on hero buttons: backdrop-blur-sm with semi-transparent background

### Badges & Labels
- Item type badges: px-3 py-1, rounded-full, text-xs font-bold, uppercase
- Level indicators: Compact, inline with other metadata
- Price display: Prominent with currency icon (VIPs/Nametags)

### Footer
- Multi-column on desktop (grid-cols-1 md:grid-cols-3)
- Social links with icon buttons (Heroicons)
- Copyright and links: text-sm
- Padding: py-12 md:py-16

## Animations
**Minimal & Purposeful**:
- Card hover: transform scale-105, transition-transform duration-200
- Button press: active:scale-95
- Form validation: Shake animation for errors
- Countdown timer: Pulse effect when < 6 hours remaining
- NO scroll-triggered animations, NO loading spinners beyond simple opacity transitions

## Icons
**Library**: Heroicons (via CDN)
**Usage**:
- Navigation: Menu, X, Home, Shopping Cart, Newspaper, Phone
- Forms: Upload, Search, Filter, ChevronDown
- Actions: Plus, Edit, Trash, ExternalLink
- Social: App Store, Google Play (use brand-specific alternatives if available)
- Size: w-5 h-5 for inline, w-6 h-6 for buttons, w-8 h-8 for hero elements

## Images
**Hero Section**: No specific hero image - use School of Chaos logo prominently with subtle gaming-themed background texture or gradient

**Event Thumbnails**: Three provided event images (Cross-Trading Ban, Spooky Season, Halloween Contest) displayed in event cards - aspect-[16/9], object-cover

**Marketplace Items**: Six provided item images displayed in marketplace listings - aspect-square, object-contain with slight padding to prevent clipping

**Image Treatment**: All images should have rounded-lg corners, maintain aspect ratios, use object-cover for event thumbnails and object-contain for item cards

## Mobile-First Specifications
- Touch targets: Minimum 44x44px (h-11 or larger)
- Bottom sheet modals for filters on mobile
- Swipeable card galleries where applicable
- Fixed bottom action buttons for forms on mobile
- Generous padding around interactive elements (p-4 minimum)
- Single column layouts default, multi-column only md+ breakpoint
- Form inputs sized for comfortable thumb typing (h-12 minimum)